#pragma once

#include <windows.h>
#include <queue>
#include <string>
#include <atomic>
#include <thread>
#include <mutex>
#include <queue>
#include <condition_variable>


#ifdef LOGGER_DLL_EXPORTS
#define LOGGER_API __declspec(dllexport)
#else
#define LOGGER_API __declspec(dllimport)
#endif

class AsyncDebugLogger
{
public:
    AsyncDebugLogger() : _running(false) {}
    ~AsyncDebugLogger()
    {
        Stop();
    }

    void Start()
    {
        bool expected = false;
        if (!_running.compare_exchange_strong(expected, true))
            return; // already running

        OutputDebugString("[cx_Profiler] Start");
        _worker = std::thread([this]() { WorkerThread(); });
    }

    void Stop()
    {
        bool expected = true;
        if (!_running.compare_exchange_strong(expected, false))
            return; // not running

        _cv.notify_one();
        if (_worker.joinable())
            _worker.join();

        // flush remaining messages
        FlushInternal();

        OutputDebugString("[cx_Profiler] Stop");
    }

    void Log(const char* msg)
    {
        if (!msg) return;

        std::lock_guard<std::mutex> lk(_mtx);
        _q.push(std::string(msg));
        _cv.notify_one();
    }

private:
    void WorkerThread()
    {
        while (_running)
        {
            std::unique_lock<std::mutex> lk(_mtx);
            _cv.wait(lk, [this]() { return !_q.empty() || !_running; });

            while (!_q.empty())
            {
                std::string s = std::move(_q.front());
                _q.pop();

                lk.unlock();
                ::OutputDebugStringA(s.c_str());
                lk.lock();
            }
        }

        FlushInternal();
    }

    void FlushInternal()
    {
        std::lock_guard<std::mutex> lk(_mtx);
        while (!_q.empty())
        {
            std::string s = std::move(_q.front());
            _q.pop();
            ::OutputDebugStringA(s.c_str());
        }
    }

private:
    std::atomic<bool> _running;
    std::thread _worker;
    std::mutex _mtx;
    std::condition_variable _cv;
    std::queue<std::string> _q;
};

namespace MyLogger {
    static AsyncDebugLogger g_logger;   // DLL ���ο��� ����ϴ� ������ Logger
}

//extern "C" {
//    LOGGER_API void Logger_InitA();
//    LOGGER_API void Logger_Start();
//    LOGGER_API void Logger_Stop();
//    LOGGER_API void Logger_Finalize();
//    LOGGER_API void Logger_LogA(const char* msg);
//}



