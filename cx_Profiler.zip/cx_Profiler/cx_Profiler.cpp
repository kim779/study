﻿// cx_Profiler.cpp : DLL의 초기화 루틴을 정의합니다.
//

#include "pch.h"
#include "framework.h"
#include "cx_Profiler.h"
#include "Logger_DLL.h"


#include <chrono>
#include <mutex>
#include <fstream>
#include <string>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

//파일 쓰기
static std::mutex g_mtx;
static std::ofstream g_log;

//
//TODO: 이 DLL이 MFC DLL에 대해 동적으로 링크되어 있는 경우
//		MFC로 호출되는 이 DLL에서 내보내지는 모든 함수의
//		시작 부분에 AFX_MANAGE_STATE 매크로가
//		들어 있어야 합니다.
//
//		예:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// 일반적인 함수 본문은 여기에 옵니다.
//		}
//
//		이 매크로는 MFC로 호출하기 전에
//		각 함수에 반드시 들어 있어야 합니다.
//		즉, 매크로는 함수의 첫 번째 문이어야 하며
//		개체 변수의 생성자가 MFC DLL로
//		호출할 수 있으므로 개체 변수가 선언되기 전에
//		나와야 합니다.
//
//		자세한 내용은
//		MFC Technical Note 33 및 58을 참조하십시오.
//

// CcxProfilerApp

BEGIN_MESSAGE_MAP(CcxProfilerApp, CWinApp)
END_MESSAGE_MAP()


// CcxProfilerApp 생성

CcxProfilerApp::CcxProfilerApp()
{
	// TODO: 여기에 생성 코드를 추가합니다.
	// InitInstance에 모든 중요한 초기화 작업을 배치합니다.
}


// 유일한 CcxProfilerApp 개체입니다.

CcxProfilerApp theApp;

const GUID CDECL _tlid = {0xa1ecc128,0x052a,0x4703,{0x90,0xe0,0xeb,0xbb,0x7e,0xf2,0x3b,0x10}};
const WORD _wVerMajor = 1;
const WORD _wVerMinor = 0;


// CcxProfilerApp 초기화

BOOL CcxProfilerApp::InitInstance()
{
	CWinApp::InitInstance();

	// OLE 서버(팩터리)를 실행 중인 것으로 등록합니다.  이렇게 하면
	//  OLE 라이브러리가 다른 애플리케이션에서 개체를 만들 수 있습니다.
	COleObjectFactory::RegisterAll();

	return TRUE;
}

// DllGetClassObject - 클래스 팩터리를 반환합니다.

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return AfxDllGetClassObject(rclsid, riid, ppv);
}


// DllCanUnloadNow - COM에서 DLL을 언로드할 수 있도록 합니다.

STDAPI DllCanUnloadNow(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if (AfxDllCanUnloadNow() != S_OK)
		return S_FALSE;

	// 2) 로거 스레드 종료 (DLL unload 직전)
	//Logger_Stop();
	//Logger_Finalize();

	//return S_OK;

	return AfxDllCanUnloadNow();
}


// DllRegisterServer - 시스템 레지스트리에 항목을 추가합니다.

STDAPI DllRegisterServer(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if (!AfxOleRegisterTypeLib(AfxGetInstanceHandle(), _tlid))
		return SELFREG_E_TYPELIB;

	if (!COleObjectFactory::UpdateRegistryAll())
		return SELFREG_E_CLASS;

	return S_OK;
}


// DllUnregisterServer - 시스템 레지스트리에서 항목을 제거합니다.

STDAPI DllUnregisterServer(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if (!AfxOleUnregisterTypeLib(_tlid, _wVerMajor, _wVerMinor))
		return SELFREG_E_TYPELIB;

	if (!COleObjectFactory::UpdateRegistryAll(FALSE))
		return SELFREG_E_CLASS;

	return S_OK;
}

//파일에 쓰기
static std::string RectToStr(const RECT* rc)
{
	if (!rc)
		return "(null)";

	char buf[128];
	sprintf_s(buf, "(%d,%d,%d,%d)", rc->left, rc->top, rc->right, rc->bottom);
	return buf;
}

extern "C" {

	void __stdcall Profiler_InitializeA(const char* logPath)
	{
		std::lock_guard<std::mutex> lock(g_mtx);

		g_log.open(logPath, std::ios::out | std::ios::trunc);
		if (!g_log.is_open())
			return;

		g_log << "[Profiler Initialized]\n";
	}

	void __stdcall Profiler_FinalizeA()
	{
		std::lock_guard<std::mutex> lock(g_mtx);

		if (g_log.is_open())
		{
			g_log << "[Profiler Finalized]\n";
			g_log.close();
		}
	}

	ULONGLONG __stdcall Profiler_BeginDrawA(HWND hWnd, const RECT* rc)
	{
		ULONGLONG tick = GetTickCount64();

		std::lock_guard<std::mutex> lock(g_mtx);
		if (g_log.is_open())
		{
			g_log << "\n\nBeginDraw HWND=" << (DWORD_PTR)hWnd
				<< " \nClip=" << RectToStr(rc)
				<< " \nTick=" << tick << "\n";
		}

		return tick;
	}

	void __stdcall Profiler_EndDrawA(HWND hWnd, ULONGLONG beginTick)
	{
		ULONGLONG end = GetTickCount64();
		ULONGLONG elapsed = end - beginTick;

		std::lock_guard<std::mutex> lock(g_mtx);
		if (g_log.is_open())
		{
			g_log << "\n\nEndDraw HWND=" << (DWORD_PTR)hWnd
				<< "\nElapsed=" << elapsed << "ms\n";
		}
	}

	void __stdcall Profiler_MarkEventA(HWND hWnd, const char* name)
	{
		std::lock_guard<std::mutex> lock(g_mtx);
		if (g_log.is_open())
		{
			g_log << "[Event] HWND=" << (DWORD_PTR)hWnd
				<< " Name=" << (name ? name : "(null)") << "\n";
		}
	}

	void __stdcall Profiler_FlushA()
	{
		std::lock_guard<std::mutex> lock(g_mtx);
		if (g_log.is_open())
			g_log.flush();
	}



}


//debugview



extern "C" {

	void __stdcall Logger_InitA()
	{

	}

	void __stdcall Logger_Start()
	{
		MyLogger::g_logger.Start();
	}

	void __stdcall Logger_Stop()
	{
		MyLogger::g_logger.Stop();
	}

	void __stdcall Logger_Finalize()
	{
		// 필요하면 리소스 정리
	}

	void __stdcall Logger_LogA(const char* msg)
	{
		MyLogger::g_logger.Log(msg);
	}

	void __stdcall Logger_Flush()
	{
		//MyLogger::g_logger
	}
}