//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CX_WEBVIEW.RC
//
#define IDM_GET_BROWSER_VERSION_AFTER_CREATION 170
#define IDM_GET_BROWSER_VERSION_BEFORE_CREATION 171
#define IDM_CREATION_MODE_TARGET_DCOMP  195
// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE	3000
#define _APS_NEXT_CONTROL_VALUE		3000
#define _APS_NEXT_SYMED_VALUE		3000
#define _APS_NEXT_COMMAND_VALUE		32771
#endif
#endif
