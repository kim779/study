#if !defined(AFX_EDGEWND_H__A7FDE7B1_BFD4_496C_A464_C07136FC4420__INCLUDED_)
#define AFX_EDGEWND_H__A7FDE7B1_BFD4_496C_A464_C07136FC4420__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EdgeWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEdgeWnd window
#include "ComponentBase.h"
#include <dcomp.h>
#include <functional>
#include <memory>
#include <ole2.h>
#include <string>
#include <vector>
#include <winnt.h>

class CEdgeWnd : public CWnd
{
// Construction
public:
	CEdgeWnd();
	CWnd* m_pWizard{};
	CParam m_Param;
	CString m_strurl;
	CString _sURL;
	bool	_bScroll{};

	void	SetParam(struct _param* pParam);
// Attributes
public:
	void InitializeWebView();
	HRESULT OnCreateEnvironmentCompleted(HRESULT result, ICoreWebView2Environment* environment);
	HRESULT OnCreateCoreWebView2ControllerCompleted(HRESULT result, ICoreWebView2Controller* controller);
	void RunAsync(std::function<void(void)> callback);
	void ResizeEverything();
	HRESULT DCompositionCreateDevice2(IUnknown* renderingDevice, REFIID riid, void** ppv);

	void CloseWebView(bool cleanupUserDataFolder = false);

	ICoreWebView2Controller* GetWebViewController()
	{
		return m_controller.get();
	}
	ICoreWebView2* GetWebView()
	{
		return m_webView.get();
	}
	ICoreWebView2Environment* GetWebViewEnvironment()
	{
		return m_webViewEnvironment.get();
	}
	HWND GetMainWindow()
	{
		return this->GetSafeHwnd();
	}
protected:
	//wil::com_ptr<ICoreWebView2_2>
	HICON m_hIcon;
	DWORD m_creationModeId = 0;
	wil::com_ptr<ICoreWebView2Environment> m_webViewEnvironment;
	wil::com_ptr<IDCompositionDevice> m_dcompDevice;
	wil::com_ptr<ICoreWebView2Controller> m_controller;
	wil::com_ptr<ICoreWebView2> m_webView;
	std::vector<std::unique_ptr<ComponentBase>> m_components;
	HWND m_mainWindow = nullptr;
	HINSTANCE g_hInstance;
	static constexpr size_t s_maxLoadString = 100;
	template <class ComponentType, class... Args> void NewComponent(Args&&... args);

	template <class ComponentType> ComponentType* GetComponent();
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEdgeWnd)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CEdgeWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CEdgeWnd)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CEdgeWnd)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
	void Navigate(BSTR sUrl);
	void Navigate_strUrl();
	void Navigate2(SHORT igubn, BSTR sUrl);
	enum
	{
		dispidNavigate2 = 4L,
		dispidGoForward = 3L,
		dispidGoBack = 2L,
		dispidNavigate = 1L
	};
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg long OnMessage(WPARAM wParam, LPARAM lParam);
protected:
	void GoBack();
	void GoForward();

public:  //weblink ��� �߰�
	CWnd* m_pMainFrame{};

	int	m_width, m_height;					// web page's size information
	bool m_bNavigate2;
	BOOL	m_bCertLogin;

	CString m_sMapName;
	CString m_slog;
	CString m_sCert;
	CString m_ipAddr;
	CString m_MacAddr;
	CString m_sRoot{};
	CString m_strUrl, m_sUrl;
	CString m_userID, m_baseURL, m_itemCode, m_home, m_menu;
	CString m_type, m_description, m_url, m_finalurl;		// web parameters & information

	void SearchURL();
	void GetInformation();

	BOOL CheckCloude();
	CString CEdgeWnd::HTSEncode(const char* lpszSource, const char* key);
	CString URLEncode(const char* lpszURL);
	CString GetUserPassword();
	CString GetCertPassword();
	CString GetAuthParam();
	CString GetURL();
	CString SetNoParam();
	CString GetFSDValue();
	LRESULT SendTR(CString strName, BYTE type, CString strData, BYTE key);
	void ResizeToFitWindow();
	
};


template <class ComponentType, class... Args> void CEdgeWnd::NewComponent(Args&&... args)
{
	m_components.emplace_back(new ComponentType(std::forward<Args>(args)...));
}

template <class ComponentType> ComponentType* CEdgeWnd::GetComponent()
{
	for (auto& component : m_components)
	{
		if (auto wanted = dynamic_cast<ComponentType*>(component.get()))
		{
			return wanted;
		}
	}
	return nullptr;
}
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDGEWND_H__A7FDE7B1_BFD4_496C_A464_C07136FC4420__INCLUDED_)
